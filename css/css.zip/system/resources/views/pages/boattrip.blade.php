@include('layouts.header')
@include('layouts.navbar')

<div class="container-fluid headd">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-xs-12 col-sm-12 boat">
            <img src="image/boat.jpg" class="img-responsive">
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-xs-12 col-sm-12" style="margin-top: 10%;">
            <h1><strong>Boat Trips:</strong></p>
                <p>Sail through the pristine waters in Arabian sea and enjoy the breathtaking view of the ocean. Our boat covers to visit one of Islands known as Jana or Juraid.You can snorkel and experience the beautiful aquatic life. Scuba diving to
                    be arranged accordingly as per the number of people. We arrange boat trips from small to bigger groups.</p>
                <p>Prices to be decided by number of Person</p>

        </div>
    </div>
</div>
@include('layouts.footer')