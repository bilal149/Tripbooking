<!-- Image Url Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image_url', 'Image Url:'); ?>

    <?php echo Form::file('image_url'); ?>

</div>
<div class="clearfix"></div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('slids.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH /home/pcocar/public_html/system/resources/views/slids/fields.blade.php ENDPATH**/ ?>