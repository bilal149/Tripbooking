<div class="table-responsive">
    <table class="table" id="abouts-table">
        <thead>
            <tr>
                <th>Welcome</th>
        <th>Heading</th>
        <th>Sub Heading</th>
        <th>Details</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($about->welcome); ?></td>
            <td><?php echo e($about->heading); ?></td>
            <td><?php echo e($about->sub_heading); ?></td>
            <td><?php echo e($about->details); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['abouts.destroy', $about->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('abouts.show', [$about->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('abouts.edit', [$about->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/pcocar/public_html/system/resources/views/abouts/table.blade.php ENDPATH**/ ?>