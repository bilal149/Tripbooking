<li class="treeview">
    <a href="#">
        <i class="fa fa-dashboard"></i>
        <span>About Us</span>
        <span class="pull-rigth-container">
            <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
 <ul class="treeview-menu">




<li class="<?php echo e(Request::is('abouts*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('abouts.index')); ?>"><i class="fa fa-edit"></i><span>Abouts</span></a>
</li>

<li class="<?php echo e(Request::is('missions*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('missions.index')); ?>"><i class="fa fa-edit"></i><span>Missions</span></a>
</li>

<li class="<?php echo e(Request::is('visions*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('visions.index')); ?>"><i class="fa fa-edit"></i><span>Visions</span></a>
</li>

 </ul>
</li>

<li class="<?php echo e(Request::is('uploaders*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('uploaders.index')); ?>"><i class="fa fa-fighter-jet"></i><span>Services</span></a>
</li>


<li class="treeview">
    <a href="#">
        <i class="fa fa-dashboard"></i>
        <span>Home Slider</span>
        <span class="pull-rigth-container">
            <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
 <ul class="treeview-menu">



<li class="<?php echo e(Request::is('slids*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('slids.index')); ?>"><i class="fa fa-edit"></i><span>Slide # 1</span></a>
</li>

<li class="<?php echo e(Request::is('slider1s*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('slider1s.index')); ?>"><i class="fa fa-edit"></i><span>Slide # 2</span></a>
</li>

<li class="<?php echo e(Request::is('slider2s*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('slider2s.index')); ?>"><i class="fa fa-edit"></i><span>Slide # 3</span></a>
</li>

 </ul>
</li>



<li class="<?php echo e(Request::is('fliers*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('fliers.index')); ?>"><i class="fa fa-edit"></i><span>Fliers</span></a>
</li>

<li class="<?php echo e(Request::is('weeks*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('weeks.index')); ?>"><i class="fa fa-edit"></i><span>Weeks</span></a>
</li>

<?php /**PATH C:\xampp\htdocs\Adventure\resources\views/layouts/menu.blade.php ENDPATH**/ ?>