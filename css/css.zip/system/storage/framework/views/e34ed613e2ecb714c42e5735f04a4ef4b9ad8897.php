<!-- Image Url Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image_url', 'Image Url:'); ?>

    <?php echo Form::text('image_url', null, ['class' => 'form-control','maxlength' => 255,'maxlength' => 255]); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('weeks.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\xampp\htdocs\Adventure\resources\views/weeks/fields.blade.php ENDPATH**/ ?>