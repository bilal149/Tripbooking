<div class="table-responsive">
    <table class="table" id="uploaders-table">
        <thead>
            <tr>
                <th>Heading</th>
        <th>Details</th>
        <th>Image Url</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $uploaders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uploader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($uploader->heading); ?></td>
            <td><?php echo e($uploader->details); ?></td>
            <td><img height="50px" class="img-rounded" width="100" height="200" src="<?php echo e($uploader->image_url); ?>" /></td>
                <td>
                    <?php echo Form::open(['route' => ['uploaders.destroy', $uploader->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <!--a href="<?php echo e(route('uploaders.show', [$uploader->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('uploaders.edit', [$uploader->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a-->
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\Adventure\resources\views/uploaders/table.blade.php ENDPATH**/ ?>