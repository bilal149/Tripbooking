<!-- Welcome Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('welcome', 'Welcome:'); ?>

    <?php echo Form::text('welcome', null, ['class' => 'form-control','maxlength' => 255,'maxlength' => 255]); ?>

</div>

<!-- Heading Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('heading', 'Heading:'); ?>

    <?php echo Form::text('heading', null, ['class' => 'form-control','maxlength' => 255,'maxlength' => 255]); ?>

</div>

<!-- Sub Heading Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('sub_heading', 'Sub Heading:'); ?>

    <?php echo Form::text('sub_heading', null, ['class' => 'form-control','maxlength' => 255,'maxlength' => 255]); ?>

</div>

<!-- Details Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('details', 'Details:'); ?>

    <?php echo Form::textarea('details', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('abouts.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH /home/pcocar/public_html/system/resources/views/abouts/fields.blade.php ENDPATH**/ ?>