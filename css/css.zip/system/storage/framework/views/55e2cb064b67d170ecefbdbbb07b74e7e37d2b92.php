<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
<?php
$uploader = App\Models\Uploader::all();
?>
<div class="container-fluid under" style="background-color: #0095D9;">
    <div class="row">
        <div class="col font text-center mt-1">
            <h1>OUR ADVENTURES</h1>
        </div>
    </div>
</div>
<div class=" waga  container">
<div class="row" > 
       
        <?php for($i=0; $i  < count($uploader);$i++): ?>
        <div class=" waga  col-md-6 col-xl-3 col-lg-3" style="display:inline-block; float: left;">
            <div class=" waga  card mb-4 mt-5" style="border:2px solid black">
                <img class=" waga  card-img-top" src="<?php echo e(asset('' . $uploader[$i]->image_url)); ?>" alt="Card image cap" style="height: 240px;">
                <div class=" waga  card-body" style="background-color: #fff">
                    <h4 class=" waga  card-title" style="height: 60px;"><?php echo e($uploader[$i]->heading); ?></h4>
                    <p class=" waga  card-text" style="height: 80px;"><?php echo e(substr(strip_tags($uploader[$i]->details), 0, 100)); ?>...</p>
                    <div class=" waga  llink"><a href="/info/<?php echo e($uploader[$i]->id); ?>"  style="color: black;"><strong>Explore More</strong></a></div>
                </div>
            </div>
        </div>
        <?php endfor; ?>
        
        
    </div>
</div>

 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Adventure\resources\views/pages/trips.blade.php ENDPATH**/ ?>