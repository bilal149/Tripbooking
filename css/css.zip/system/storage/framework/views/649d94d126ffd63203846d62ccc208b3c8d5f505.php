<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- --------------------------- Welcome to Adventure Khobar--------------------------------------------- -->
    <div class="container-fluid under" style="background-color: #0095D9;">
        <div class="row">
            <div class="col font text-center mt-1">
                <h1>ABOUT US</h1>
            </div>
        </div>
    </div>
    <div class="container mt-5 mb-5">

        <div class="row my-row font">
            <div class="col-lg-0 col-xl-0 my-col">

            </div>
            <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-5 col-xl-5 my-col">
                <img src="image/home-about.png" class="mb-2" width="100%">
            </div>
            
            <?php
            //$data= App\About::all();
            $abouts = App\Models\About::all();
            ?>
    
    <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 my-col mb-2 mt-5">
                <h1><span style="color: #0095D9;"> <strong>  <?php echo e($data->welcome); ?> </span> <br> <span style="color:black;"> <?php echo e($data->heading); ?> </span></strong>
                </h1>
                <h3><strong><?php echo e($data->sub_heading); ?></strong></h3>
                <br>
                <p><?php echo e($data->details); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </div>
            <div class="col-lg-1 col-xl-1 my-col">

            </div>
        </div>
    </div>
    <div class="vision">
        <div class="container mt-5 mb-5">

            <div class="row my-row font">
                
                <?php
                $visions = App\Models\Vision::all();
                ?>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 my-col mb-2 mt-5">
                    <div class="vision1">
                        <?php $__currentLoopData = $visions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h1 class="mb-3 mt-1"><?php echo e($data->heading); ?> </h1>
                        <p><?php echo e($data->details); ?> </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </div>
                </div>


                <?php
                $missions = App\Models\Mission::all();
                ?>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 my-col mb-2 mt-5" >
                    <div class="vision1">
                        <?php $__currentLoopData = $missions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h1 class="mb-3 mt-1"><?php echo e($data->heading); ?> </h1>
                        <p><?php echo e($data->details); ?> </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>



            </div>
        </div>
      
      <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php /**PATH /home/pcocar/public_html/system/resources/views/pages/about_us.blade.php ENDPATH**/ ?>