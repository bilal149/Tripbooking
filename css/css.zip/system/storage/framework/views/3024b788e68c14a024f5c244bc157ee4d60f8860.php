
<body>
    <!-- ------------------------------ header------------------------------------------ -->
    <div class="back-color display">
        <div class="container  icons waga ">
            <div class="row my-row    waga ">

                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3  mt-2 col-xs-12   my-col waga">
                    <img src="../../image/icon_call.svg" alt="" class=" mr-2"><span>050-3222972</span>

                </div>
                <div class="col-xl-3 col-lg-4 col-md-5 col-sm-5 mt-2  col-xs-12  my-col waga" >
                    <img src="../../image/icon_email.svg" alt="" class=" mr-2"><span>Info@adventurekhobar.com</span>


                </div>
               
                <div class="col-xl-6 col-lg-5 col-md-4 col-sm-4   col-xs-12 my-col   SocialIcons">
                    <a href="https://www.facebook.com/adventurekhobar/" target="_blank" class="fab fa-facebook-f"></a>
                    <a href="https://www.instagram.com/adventurekhobar/" target="_blank" class="fab fa-instagram"></a>
                    <a href="https://api.whatsapp.com/send?phone=0503222972" target="_blank" class="fab fa-whatsapp"></a>
                </div>
            </div>
        </div>
    </div>


    <!-- ------------------------------- navbar----------------------------------------- -->
    <div class="container waga" style="height: auto">
        <div class="row my-row font waga">

            <div class="col-xl-3 col-lg-3 col-md-8 col-sm-6 col-xs-6 my-col mt-2 mb-1 waga">
                <img class="img-fluid  mx-auto d-block" src="../../image/logo.png" alt="" href="/">
            </div>
            <div class="col-xl-9 col-lg-9 col-md-4 col-sm-6  col-xs-6 mt-2 mb-1 mt-3  my-col waga">

                <nav class="navbar navbar-expand-lg navbar-light bg-white">
                    <a class="navbar-brand" href="#"></a>
                    <button class="navbar-toggler bg-white tabbtn" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                    <div class="collapse navbar-collapse" id="navbarNavDropdown">
                        <ul class="navbar-nav">
                            <li class="nav-item active">
                                <a class="nav-link font" href="/">HOME</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link font" href="/about_us">ABOUT US</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link font" href="/trips">OUR ADVENTURES</a>
                            </li>
                            <!-- <li class="nav-item">
                                <a class="nav-link font" href="services.html">OUR SERVICE</a>
                            </li>-->
                            <!--    <li class="nav-item">
                                <a class="nav-link font" href="#">OUR PACKAGES</a>
                            </li>-->
                            <li class="nav-item">
                                <a class="nav-link font" href="/booktrip">BOOK TRIP</a>
                            </li>
                           
                            <!--  <li class="nav-item">
                                <a class="nav-link font" href="#">FORUM</a>
                            </li>-->
                            <li class="nav-item">
                                <a class="nav-link font" style="background-color: #000; color: #fff;" href="/sendemail">CONTACT US</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
<?php /**PATH /home/pcocar/public_html/system/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>