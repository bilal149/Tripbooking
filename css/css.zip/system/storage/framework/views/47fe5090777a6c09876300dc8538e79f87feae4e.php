<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- -------------------------------------Services------------------------------------- -->
 <div class="container-fluid under" style="background-color: #0095D9;">
        <div class="row">
            <div class="col font text-center mt-1">
                <h1>OUR ADVENTURES</h1>
            </div>
        </div>
    </div>
 <div class="container-fluid headd">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-xs-12 col-sm-12 scuba" style="background: url(<?php echo e(asset('' . $data->image_url)); ?>);height: 600px; background-repeat: no-repeat;">
          
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-xs-12 col-sm-12" style="margin-top: 4%;">
            <h1><?php echo e($data->heading); ?></h1>
            <p>
                <?php echo e($data->details); ?>

            </p>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pcocar/public_html/system/resources/views/pages/service.blade.php ENDPATH**/ ?>